import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const App = () => {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  const Calculadora = (operacao) => {
    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);
    let res;

    if (isNaN(number1) || isNaN(number2)) {
      alert("Por favor, insira números válidos.");
      return;
    }

    switch (operacao) {
      case 'add':
        res = number1 + number2;
        break;
      case 'subtract':
        res = number1 - number2;
        break;
      case 'multiply':
        res = number1 * number2;
        break;
      case 'divide':
        if (number2 === 0) {
          alert("Divisão por zero não é permitida.");
          return;
        }
        res = number1 / number2;
        break;
      default:
        return;
    }

    setResult(res);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora Simples</Text>
      <TextInput
        style={styles.input}
        placeholder="Número 1"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
        style={styles.input}
        placeholder="Número 2"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />
      <View style={styles.buttonContainer}>
        <Button title="+" onPress={() => Calculadora('add')} />
        <Button title="-" onPress={() => Calculadora('subtract')} />
        <Button title="*" onPress={() => Calculadora('multiply')} />
        <Button title="/" onPress={() => Calculadora('divide')} />
      </View>
      {result !== null && (
        <Text style={styles.result}>Resultado: {result}</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 20,
  },
  result: {
    fontSize: 20,
    textAlign: 'center',
    marginTop: 20,
  },
});

export default App;